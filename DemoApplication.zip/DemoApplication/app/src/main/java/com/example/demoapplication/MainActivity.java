package com.example.demoapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button hello_world = findViewById(R.id.hello_world);

        Animation move = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.move);
        Animation scale = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.scale);
        Animation rotate = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
        Animation alpha = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.alpha);

        hello_world.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hello_world.startAnimation(alpha);
            }
        });

//        hello_world.setOnClickListener(view -> {
//            Intent intent;
//            intent = new Intent(getApplicationContext(), MainActivity2.class);
//            intent.putExtra("studentName","Dipak Patil");
//            intent.putExtra("studentRollNo",23);
//            intent.putExtra("status",true);
//            startActivity(intent);
//        });
    }
}